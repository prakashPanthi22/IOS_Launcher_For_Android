package com.example.veeru.ioslauncher;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static android.R.attr.button;
import static com.example.veeru.ioslauncher.R.attr.title;
import static com.example.veeru.ioslauncher.R.id.end;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    public Button button, cam, geog, what, map, you, phone, calender;

    // Remove the below line after defining your own ad unit ID.
    private static final String TOAST_TEXT = "Test ads are being shown. "
            + "To show live ads, replace the ad unit ID in res/values/strings.xml with your own ad unit ID.";

    private static final int START_LEVEL = 1;
    private int mLevel;
    private Button mNextLevelButton;
    private InterstitialAd mInterstitialAd;
    private TextView mLevelTextView;
    private static final int CAMERA_REQUEST = 123;
    private Button video, instagss;
    private static final int VIDEO_REQUEST = 123;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);








        button = (Button) findViewById(R.id.menu);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FullscreenActivity.class);
                startActivity(intent);

            }
        });
        //icons

        calender = (Button) findViewById(R.id.calender);
        cam = (Button) findViewById(R.id.camera);
        geog = (Button) findViewById(R.id.google);
        what = (Button) findViewById(R.id.whatsapp);
        map = (Button) findViewById(R.id.map);
        you = (Button) findViewById(R.id.youtube);
        phone = (Button) findViewById(R.id.phone);
        // Button   safari= (Button) findViewById(R.id.safari);
        video = (Button) findViewById(R.id.video);
        instagss = (Button) findViewById(R.id.instagram);



        cam.setOnClickListener(this);
        calender.setOnClickListener(this);
        geog.setOnClickListener(this);
        what.setOnClickListener(this);
        map.setOnClickListener(this);
        you.setOnClickListener(this);
        phone.setOnClickListener(this);

        video.setOnClickListener(this);
        instagss.setOnClickListener(this);


        // Create the next level button, which tries to show an interstitial when clicked.
        mNextLevelButton = ((Button) findViewById(R.id.facebook));
        mNextLevelButton.setEnabled(false);
        mNextLevelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInterstitial();
            }
        });

        // Create the text view to show the level number.
        mLevelTextView = (TextView) findViewById(R.id.phone);
        mLevel = START_LEVEL;

        // Create the InterstitialAd and set the adUnitId (defined in values/strings.xml).
        mInterstitialAd = newInterstitialAd();
        loadInterstitial();

        // Toasts the test ad message on the screen. Remove this after defining your own ad unit ID.
        Toast.makeText(this, TOAST_TEXT, Toast.LENGTH_LONG).show();


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private InterstitialAd newInterstitialAd() {
        InterstitialAd interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.interstitial_ad_unit_id));
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mNextLevelButton.setEnabled(true);
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                mNextLevelButton.setEnabled(true);
            }

            @Override
            public void onAdClosed() {
                // Proceed to the next level.
                goToNextLevel();
            }
        });
        return interstitialAd;
    }

    private void showInterstitial() {
        // Show the ad if it's ready. Otherwise toast and reload the ad.
        if (mInterstitialAd != null && mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            Toast.makeText(this, "Ad did not load", Toast.LENGTH_SHORT).show();
            goToNextLevel();
        }
    }

    private void loadInterstitial() {
        // Disable the next level button and load the ad.
        mNextLevelButton.setEnabled(false);
        AdRequest adRequest = new AdRequest.Builder()
                .setRequestAgent("android_studio:ad_template").build();
        mInterstitialAd.loadAd(adRequest);
    }

    private void goToNextLevel() {
        // Show the next level and reload the ad to prepare for the level after.
        mLevelTextView.setText("Level " + (++mLevel));
        mInterstitialAd = newInterstitialAd();
        loadInterstitial();
    }


    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.youtube:
                OpenYouTube();
                break;
            case R.id.google:
                OpenWebPage();
                break;
            case R.id.whatsapp:
                OpenWhats();
                break;
            case R.id.map:
                OpenMap();
                break;
            case R.id.phone:
                OpenDialer();
                break;

            case R.id.camera:
                opencamm();
                break;
            case R.id.video:
                openvideo();
                break;
            case R.id.instagram:
                openinsta();
                break;
            case R.id.facebook:
                opfacebook();
                break;
            case R.id.calender:
                opcalender();
                break;
            case R.id.mail:
                opmail();
                break;

            case R.id.gallery:
                opgallery();
                break;

            case R.id.settings:
                opsetting();
                break;

            case R.id.music:
                opmusic();
                break;
            case R.id.calculator:
                opcalc();
                break;
            case R.id.message:
                opmessage();
                break;

            case R.id.videogallery:
                opvideogallery();
   case R.id.playstore:







        }
    }

    private void opplaystore() {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.android.vending");
        ComponentName comp = new ComponentName("com.android.vending", "com.google.android.finsky.activities.LaunchUrlHandlerActivity"); // package name and activity
        launchIntent.setComponent(comp);
        launchIntent.setData(Uri.parse("market://details?id=com.facebook.katana"));

        startActivity(launchIntent);
    }

    private void opvideogallery() {

        Intent myIntent ;
        PackageManager manager = getPackageManager();
        myIntent = manager.getLaunchIntentForPackage("com.mxtech.videoplayer.ad");
        startActivity(myIntent);
    }

    private void opmessage() {


        Intent sendIntent = new Intent(Intent.ACTION_VIEW);
        sendIntent.setData(Uri.parse("sms:"));
        startActivity(sendIntent);


    }

    private void opcalc() {
        Intent i = new Intent();
        i.setClassName("com.android.calculator2",
                "com.android.calculator2.Calculator");
    }

    public static final int RESULT_GALLERY = 0;





    private void opgallery() {

        Intent i = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        final int ACTIVITY_SELECT_IMAGE = 1234;
        startActivityForResult(i, ACTIVITY_SELECT_IMAGE);
    }

    private void opsetting() {

        startActivity(
                new Intent(Settings.ACTION_SETTINGS));
    }


    private void opmusic() {
        Intent intent = new Intent("android.intent.action.MUSIC_PLAYER");
        startActivity(intent);
    }


    private void opmail() {
        Intent intent=Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_EMAIL);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//Min SDK 15
        startActivity(intent);
    }



    private void opcalender() {
        Intent i = new Intent();

//Froyo or greater (mind you I just tested this on CM7 and the less than froyo one worked so it depends on the phone...)


        ComponentName cn = new ComponentName("com.google.android.calendar", "com.android.calendar.LaunchActivity");

//less than Froyo
        cn = new ComponentName("com.android.calendar", "com.android.calendar.LaunchActivity");

        i.setComponent(cn);
        startActivity(i);
    }


    private void opfacebook() {
        Uri webpack = Uri.parse("http://www.facebook.com");
        Intent intent = new Intent(Intent.ACTION_VIEW, webpack);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }


    private void openinsta() {
        Uri webpack = Uri.parse("http://www.instagram.com");
        Intent intent = new Intent(Intent.ACTION_VIEW, webpack);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);

        }
    }

    private void openvideo() {

        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(intent, VIDEO_REQUEST);
    }

    private void opencamm() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA_REQUEST);

    }


    private void OpenMap() {

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("geo:12.41,77.44"));
        Intent choose = Intent.createChooser(intent, "Launch Maps");
        startActivity(choose);
    }


    private void OpenDialer() {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + "0"));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }





    private void OpenWhats() {


        Intent i = new Intent(Intent
        startActivity(i);
    }



    private void OpenWebPage() {
        Uri webpack=Uri.parse("http://www.google.com");
        Intent intent = new Intent( Intent.ACTION_VIEW,webpack);
        if(intent.resolveActivity(getPackageManager())!=null){
            startActivity(intent);
        }
    }

    private void OpenYouTube() {

        Uri webpage=Uri.parse("http://www.youtube.com");
        Intent intent = new Intent( Intent.ACTION_VIEW,webpage);
        if(intent.resolveActivity(getPackageManager())!=null){
            startActivity(intent);
        }
    }
/*
@Override
    public  void  onBackPressed(){
    //do nothing
}*/
    }




