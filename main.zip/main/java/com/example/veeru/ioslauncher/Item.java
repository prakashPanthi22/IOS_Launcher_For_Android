package com.example.veeru.ioslauncher;

import android.graphics.drawable.Drawable;

/**
 * Created by veeru on 08-Sep-17.
 */

public class Item {
    CharSequence label;
    CharSequence name;
    Drawable icon;

}
